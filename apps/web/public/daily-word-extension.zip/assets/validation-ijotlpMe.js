function r(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function a(e,t){if(!e.trim()||!t)return!1;const n=r(t);return new RegExp(`\\b${n}\\b`,"i").test(e)}const i=a;export{i as v};
